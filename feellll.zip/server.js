const express = require('express')
const mongoose = require('mongoose')
const articleRouter = require('./routes/articles')
const app = express()

const mongoUrl = "mongodb://localhost/Blog";

const connectToMongo = async () => {
    try {
      await mongoose.connect(mongoUrl, { useNewUrlParser: true });
      console.log('connected to MongoDB');
    } catch(error) {
      console.log('error connection to MongoDB:', error.message);
    }
  };

app.set('view engine', 'ejs')

app.use(express.urlencoded({extended: false}))

app.get('/', (req, res) => {

    const articles = [{
        title: 'overall review',
        createdAt: new Date(),
        description: 'review description'
    },
    {
        title: 'overall review 2',
        createdAt: new Date(),
        description: 'review Description 2'
    }
]

    res.render('articles/index', {articles: articles})
})
app.use('/articles', articleRouter)


app.listen(5000)